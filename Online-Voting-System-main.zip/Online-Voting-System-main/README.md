# Online-Voting-System
The Online Voting System is built upon the client-server paradigm, utilizing the TCP/IP protocol for communication between clients and servers. The client, representing the voter, interacts with the server, which houses the central database containing information on candidates, registered voters, and cast votes. 
